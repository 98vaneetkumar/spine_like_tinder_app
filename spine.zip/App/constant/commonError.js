const message =()=>{

common_error = "Something Went Wrong"
get_profile ="Get Profile Successfully"
get_list ="Get List Successfully"
registet_success ="Register Successfully" 
}